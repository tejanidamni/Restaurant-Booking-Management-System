
public interface RState {
	
	public String genMsg(Reservation r);
	public boolean equals(Object o);

}
