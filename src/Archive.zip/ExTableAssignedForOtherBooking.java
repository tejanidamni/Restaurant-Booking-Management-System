
public class ExTableAssignedForOtherBooking extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public ExTableAssignedForOtherBooking() { super(); }
	public ExTableAssignedForOtherBooking(String message) { super(message); }
}
